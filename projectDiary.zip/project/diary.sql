-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2019 at 09:45 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `diary`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` varchar(100) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `article` longtext NOT NULL,
  `title` text NOT NULL,
  `Date1` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `username`, `article`, `title`, `Date1`) VALUES
('gmy first memory', 'g', '', 'my first memory', ''),
('gtitle1', 'g', '', 'sample title ', ''),
('roottitle1', 'root', 'enter your memory', 'www1114444 ', ''),
('gtitle2', 'g', 'enter memory here55', 'enter title of memory555', ''),
('renukatitle1', 'renuka', 'enter details123', 'enter title of notes  ', '4 December 2017'),
('renukatitle2', 'renuka', 'enter details', 'enter title of 456notes', '4 December 2017'),
('renuka', 'renuka', '', '', '4 December 2017 09:02:45 AM'),
('anjali', 'anjali', '', '', '4 December 2017 09:40:57 AM'),
('anjalititle2', 'anjali', 'enter details123', 'enmmm', '4 December 2017 09:41:38 AM'),
('anjalititle6', 'anjali', 'enter deta11111ils', 'enter title of notes', '4 December 2017 09:49:52 AM'),
('Mayurititle1', 'Mayuri', '1Lectures 2practical 3assignment', 'Todays Schedule   ', '4 December 2017 04:35:02 PM'),
('Mayurititle2', 'Mayuri', '1Java 2PHP 3OSC', 'Subjects for this semister', '4 December 2017 04:35:49 PM'),
('Mayurititle3', 'Mayuri', '1 Xampp 2eclipse 3netbeans 4MSOffice', 'List of Softwares to download', '4 December 2017 05:01:01 PM'),
('Mayurititle4', 'Mayuri', 'Tomorrow i have extra lectures for Microprocesseor and M4', '', '5 December 2017 10:03:09 AM'),
('Mayurititle5', 'Mayuri', 'we have to submit report on 9th December for php projectFor that we will have to complete remaining work till saturday', '', '6 December 2017 04:16:26 AM'),
('Shwetatitle1', 'Shweta', 'enter note in detailkksajdkJLSL', 'save page', '6 December 2017 04:19:45 AM'),
('Mayurititle6', 'Mayuri', 'Today their was a eassy compitition in our college the topic was Need of Personality DevelopmentAnd i got 2nd prize for thatVery Happy Today', 'Yeah I won', '7 December 2017 01:17:10 AM'),
('Mayurititle7', 'Mayuri', 'write whatever you want', 'this is my page', '12 December 2017 06:52:59 PM');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE IF NOT EXISTS `registrations` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`username`, `email`, `password`) VALUES
('renuka', 'xyz@gmail.com', '202cb962ac59075b964b07152d234b70'),
('pqr', 'pqr@gmail.com', '202cb962ac59075b964b07152d234b70'),
('opp', 'xyz@gmail.com', '202cb962ac59075b964b07152d234b70'),
('renuka9', 'pqr@gmail.com', '202cb962ac59075b964b07152d234b70'),
('g', 'g@gmail.com', '202cb962ac59075b964b07152d234b70'),
('renuka1', 'renukartamboli@gmail.com', 'caaeb3866a61606daf4d30cf0994913d'),
('qwe', 'pqr@gmail.com', '202cb962ac59075b964b07152d234b70'),
('renuka2', 'renukartamboli@gmail.com', '202cb962ac59075b964b07152d234b70'),
('anjali', 'anjali@gmail.com', '202cb962ac59075b964b07152d234b70'),
('Mayuri', 'mayuri@gmail.com', '202cb962ac59075b964b07152d234b70'),
('Shweta', 'shweta123@gmail.com', '202cb962ac59075b964b07152d234b70');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
