<?php
include 'db1.php';
$content=preg_replace('/[^a-z0-9$¢£€¥ ]+/ui', '', $_POST['c1']);
$title=preg_replace('/[^a-z0-9$¢£€¥ ]+/ui', '', $_POST['t1']);

$user1 = $_POST['user1'];
$idp = $_POST['ids'];
$id = $user1.''.$idp;
$date = date('j F Y h:i:s A');






 $sql = "SELECT * FROM articles WHERE id ='$id'";
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
               // echo "<p>" . $row['FirstName'] . "</p>";
                 $sql1 = "update articles set  article='$content',title='$title' where id='$id'";  
                  if ($conn->query($sql1) === TRUE) {
                    echo "Your memory updated successfully";
               } else {
                 echo "Error: " . $sql . "<br>" . $conn->error;
                 }        
            }
            // Close result set
            mysqli_free_result($result);
        } else{
            
               $sql1 = "INSERT INTO articles VALUES ('$id', '$user1','$content','$title','$date')";
               if ($conn->query($sql1) === TRUE) {
                    echo "Your memory saved successfully";
               } else {
                 echo "Error: " . $sql . "<br>" . $conn->error;
                 }


        }
}
?>