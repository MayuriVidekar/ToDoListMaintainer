<?php
include 'db1.php';
$editData = $_POST['data'];
$user1 = $_POST['user'];
//$id = uniqid();

$sql = "INSERT INTO articles
VALUES ('$user1', 2,now(),'$editData','text')";

if ($conn->query($sql) == TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



?>