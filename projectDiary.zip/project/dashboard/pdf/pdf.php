
<?php
require_once("config.php");
//

require('fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();

// code for print Heading of tables
$pdf->SetFont('Arial','B',12);	
//$ret ="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='diary' AND `TABLE_NAME`='articles'";
/*$ret ="SELECT * FROM articles";
$query1 = $dbh -> prepare($ret);
$query1->execute();
$header=$query1->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query1->rowCount() > 0)
{
foreach($header as $heading) {
foreach($heading as $column_heading)
$pdf->Cell(46,12,$column_heading,1);
}}*/
//

//code for print data
$user = $_GET['user'];
$sql = "SELECT Date1,title,article from  articles where username=$user";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
$i=1;
$p=0;
foreach($results as $row) {
	$pdf->SetFont('Arial','',12);	
	$pdf->Ln();
	//$pdf->Cell(180,5,"Note:".$i,0,1,'L');
	
	foreach($row as $column){
           if($p==0){
           	$pdf->Cell(180,20,"Date:".$column,0,1,'L');
           }  
           else{      
        	$pdf->Cell(180,10,$column,0,1,'C');
           }
           $p = $p+1;
	}
	$p=0;
	$i = $i+1;
} }
$pdf->Output();
?>




