<!DOCTYPE html>
<html >
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <meta charset="UTF-8">
  <title>Dashboard</title>
  
    
  
      <link rel="stylesheet" href="css/style.css">

       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
</head>


<?php
	require('../db.php');
  header('Cache-Control: no cache'); 
  session_cache_limiter('private_no_expire');
	session_start();
    
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); 
		$username = mysqli_real_escape_string($con,$username); 
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	
        $query = "SELECT * FROM `registrations` WHERE username='$username' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
        $usern = $_SESSION['username'];
			
            




$paracontent = "empty";
$titlecontent = "empty";
$date = "empty";
function selecttitle($titleid)
{
     include 'db1.php';
     $id1 = $_SESSION['username']."".$titleid;
     $sql = "SELECT title FROM articles where id='$id1'";               
                     $result = $conn->query($sql);
                     $titlecontent = "enter title";
                    if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                      //$paracontent =  $row['article'];
                     $titlecontent = $row['title'];

                    //return $id1;
                
}
}
           return $titlecontent;
}
function selectpara($titleid)
{
      include 'db1.php';
      $id1 = $_SESSION['username']."".$titleid;
     $sql = "SELECT article FROM articles where id='$id1'";
                       $paracontent = "Write Note...";
                      $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                       $paracontent =  $row['article'];
                      // $titlecontent = $row['title'];

}
}
            return $paracontent;
}
function selectdate($titleid)
{
      include 'db1.php';
      $id1 = $_SESSION['username']."".$titleid;
     $sql = "SELECT Date1 FROM articles where id='$id1'";
                       $date = date('j F Y h:i:s A');
                      $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                       $date =  $row['Date1'];

                      // $titlecontent = $row['title'];

}
}
            return $date;
}
echo "<body>";
 echo "<span contenteditable='false' class=\"bckg\"></span>";
echo "<header>";
echo  "<h1>Dashboard</h1>";
echo  "<nav>";
echo    "<ul>";
 echo     "<li>";
   echo  " <a data-title=\"Diary\">Diary</a>";
   echo "</li>";
   echo   "<li>";
    echo  " <a href='about.html'>About Us</a>";
     echo "</li>";
     echo "<li>";
      echo "<a href=# data-title=\"Compose\" onclick='compose()'>Compose</a>";
      echo "</li>";
      echo "<li>";
       echo "<a href='pdf/pdf.php?user=\"$usern\"' data-title=\"PDF\" id='pdf'>Generate PDF</a>";
      echo "</li>";
      //echo "<li>";
       //echo "<a href=# data-title=\"Settings\">Settings</a>";
      //echo "</li>";
      echo "<li>";
      echo  "<a href=\"../logout.php\" data-title=\"Search\">logout</a>";
      echo "</li>";
    echo "</ul>";
  echo "</nav>";
echo "</header>";
echo "<main>";
echo  "<div class=\"title\">";
 echo    "<h2>Notes...</h2>";
 
 echo "<a href=\"javascript:void(0);\">Hello"." ".$_SESSION['username']."!</a>";
 echo "</div>";
  echo "<article class='larg' >";
   echo " <div id='1' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>";

    echo  "<h3 id='title1'  >".selecttitle('title1')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title1')."</span> </h3>";
       echo   "<p  id='para1' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title1')."<button class='btn-primary' contenteditable='false' style='float:right' id='save1' onclick=save(this,'#para1','#title1') >Save</button></p>";
   echo  "</div>";
    echo " <div id='2'>";
    echo  "<h3 id='title2' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title2'). "<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title2')."</span></h3>";
       echo   "<p id='para2' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title2')."<button class='btn-primary' contenteditable='false' style='float:right' id='save2' onclick=save(this,'#para2','#title2')>Save</button></p>";
   echo  "</div>";
     echo " <div id='3'>";
    echo  "<h3 id='title3' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title3')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title3')."</span></h3>";
       echo   "<p id='para3' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title3')."<button class='btn-primary' contenteditable='false' style='float:right' id='save3' onclick=save(this,'#para3','#title3')>Save</button></p>";
   echo  "</div>";


   /* echo " <div id='4'>";
    echo  "<h3 id='title4' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title4') ."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title4')."</span></h3>";
       echo   "<p id='para4' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title4')."<button class='btn-primary' contenteditable='false' style='float:right' id='save4' onclick=save(this,'#para4','#title4')>Save</button></p>";
   echo  "</div>";

   


   echo " <div id='5'>";
    echo  "<h3 id='title5' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title5')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title5')."</span></h3>";
       echo   "<p id='para5' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title5')."<button class='btn-primary' contenteditable='false' style='float:right' id='save5' onclick=save(this,'#para5','#title5')>Save</button></p>";
   echo  "</div>";*/


    echo " <div id='6'>";
    echo  "<h3 id='title6' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title6')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title6')."</span></h3>";
       echo   "<p id='para6' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title6')."<button class='btn-primary' contenteditable='false' style='float:right' id='save6' onclick=save(this,'#para6','#title6')>Save</button></p>";
  
   echo  "</div>";
    echo " <div id='7'>";
    echo  "<h3 id='title7' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title7')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title7')."</span></h3>";
       echo   "<p id='para7' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title7')."<button class='btn-primary' contenteditable='false' style='float:right' id='save7' onclick=save(this,'#para7','#title7')>Save</button></p>";
   echo  "</div>";
    echo " <div id='8'>";
    echo  "<h3 id='title8' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title8')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title8')."</span></h3>";
       echo   "<p id='para8' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title8')."<button class='btn-primary' contenteditable='false' style='float:right' id='save8' onclick=save(this,'#para8','#title8')>Save</button></p>";
   echo  "</div>";
    echo " <div id='9'>";
    echo  "<h3 id='title9' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title9')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title9')."</span></h3>";
       echo   "<p id='para9' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title9')."<button class='btn-primary' contenteditable='false' style='float:right' id='save9' onclick=save(this,'#para9','#title9')>Save</button></p>";

   echo  "</div>";

    echo " <div id='10'>";
    echo  "<h3 id='title10' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title10')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title10')."</span></h3>";
       echo   "<p id='para10' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title10')."<button class='btn-primary' contenteditable='false' style='float:right' id='save10' onclick=save(this,'#para10','#title10')>Save</button></p>";
   echo  "</div>";

    echo " <div id='11'>";
    echo  "<h3 id='title11' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title11')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title11')."</span></h3>";
       echo   "<p id='para11' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title11')."<button class='btn-primary' contenteditable='false' style='float:right' id='save11' onclick=save(this,'#para11','#title11')>Save</button></p>";
   echo  "</div>";


   echo " <div id='12'>";
    echo  "<h3 id='title12' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title12')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title12')."</span></h3>";
       echo   "<p id='para12' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title12')."<button class='btn-primary' contenteditable='false' style='float:right' id='save12' onclick=save(this,'#para12','#title12')>Save</button></p>";
   echo  "</div>";


    echo " <div id='13'>";
    echo  "<h3 id='title13' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title13')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title13')."</span></h3>";
       echo   "<p id='para13' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title13')."<button class='btn-primary' contenteditable='false' style='float:right' id='save13' onclick=save(this,'#para13','#title13')>Save</button></p>";
   echo  "</div>";


    echo " <div id='14'>";
    echo  "<h3 id='title14' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title14')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title14')."</span></h3>";
       echo   "<p id='para14' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title14')."<button class='btn-primary' contenteditable='false' style='float:right' id='save14' onclick=save(this,'#para14','#title14')>Save</button></p>";
   echo  "</div>";


    echo " <div id='15'>";
    echo  "<h3 id='title15' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title15')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title15')."</span></h3>";
       echo   "<p id='para15' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title15')."<button class='btn-primary' contenteditable='false' style='float:right' id='save15' onclick=save(this,'#para15','#title15')>Save</button></p>";
   echo  "</div>";

    echo " <div id='16'>";
    echo  "<h3 id='title16' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title16')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title16')."</span></h3>";
       echo   "<p id='para16' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title16')."<button class='btn-primary' contenteditable='false' style='float:right' id='save16' onclick=save(this,'#para16','#title16')>Save</button></p>";
   echo  "</div>";

    echo " <div id='17'>";
    echo  "<h3 id='title17' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title17')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title17')."</span></h3>";
       echo   "<p id='para17' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title17')."<button class='btn-primary' contenteditable='false' style='float:right' id='save17' onclick=save(this,'#para17','#title17')>Save</button></p>";
   echo  "</div>";

    echo " <div id='18'>";
    echo  "<h3 id='title18' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title18')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title18')."</span></h3>";
       echo   "<p id='para18' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title18')."<button class='btn-primary' contenteditable='false' style='float:right' id='save18' onclick=save(this,'#para18','#title18')>Save</button></p>";
   echo  "</div>";

    echo " <div id='19'>";
    echo  "<h3 id='title19' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title19')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title19')."</span></h3>";
       echo   "<p id='para19' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title19')."<button class='btn-primary' contenteditable='false' style='float:right' id='save19' onclick=save(this,'#para19','#title19')>Save</button></p>";
   echo  "</div>";

    echo " <div id='20'>";
    echo  "<h3 id='title12' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selecttitle('title20')."<span contenteditable='false'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date:".selectdate('title20')."</span></h3>";
       echo   "<p id='para20' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>".selectpara('title20')."<button class='btn-primary' contenteditable='false' style='float:right' id='save20' onclick=save(this,'#para20','#title20')>Save</button></p>";
   echo  "</div>";

  



  echo "</article>";
echo"</main>";
  
 //echo "<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>";
echo "<script>
var id = 8;
function compose()
{
  var idiv = document.createElement('div');

idiv.id = id;
 
document.getElementsByClassName('larg')[0].appendChild(idiv);

var h = document.createElement('h3');


idiv.appendChild(h);
  var text = document.createTextNode('enter title of memory');
  h.appendChild(text);

var span1 = document.createElement('span');
span1.className = 'entypo-down-open';
h.appendChild(span1);
var para = document.createElement('p');
idiv.appendChild(para);
id++;
}
    
function save(e,f,t){
     \$savebutton = \$(e).attr('id');
    \$contentp = \$(f).attr('id');
    \$titlep = \$(t).attr('id');
    \$content = \$(f).clone().children().remove().end().text();
    
       
    \$title = \$(t).clone().children().remove().end().text();
    \$.ajax({
        type: 'post',
        url: 'get.php',
        data: {t1:\$title,c1:\$content,user1:'$usern',ids:\$titlep},
        datatype: 'html',
        success: function(rsp){
        alert(rsp);
      }
    });
}
function pdf(){
  \$.ajax({
        type: 'post',
        url: 'pdf/pdf.php',
        data: {user1:'$usern'},
        datatype: 'html',
        success: function(rsp){
        alert(rsp);
      }
    });
}
</script>";

echo "<script  src=\"js/index.js\"></script>";
echo "</body>";
echo "</html>";


}
else{
        echo "<div class='form'><h3 id='title' contenteditable='true' style=' word-wrap: break-word;
  word-break: break-all;overflow-wrap: normal'>Username/password is incorrect.</h3><br/>Click here to <a href='index.php'>Login</a></div>";
        }
    }else{

    }?>
  
