<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "diary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 





 session_start();
$_SESSION['username'] = $_POST['usernamereg'];
$_SESSION['email'] = $_POST['emailreg'];

$_SESSION['msg'] = "username already exist";
if(isset($_POST['usernamereg'])){
    // Attempt select query execution

    $sql = "SELECT * FROM registrations WHERE username LIKE '" . $_POST['usernamereg'] . "%'";
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
           // while($row = mysqli_fetch_array($result)){
               // echo "<p>" . $row['FirstName'] . "</p>";
                //echo "<meta http-equiv=\"refresh\" content=\"0;url=".$_SERVER['HTTP_REFERER']."\"/>";
                  //echo mysqli_num_rows($result);
                   
                  echo"<meta HTTP-EQUIV='REFRESH' content='0; url=index.php#toregister'>";
                        //http_redirect("index.php#toregister");
            //}
            // Close result set
            mysqli_free_result($result);
        }

        else{


                     if($_POST['passwordreg'] != $_POST['passwordc']){
      // echo"<meta HTTP-EQUIV='REFRESH' content='0; url=index.php#toregister'>";
                      $_SESSION['msg2'] = "not matching";
                      $_SESSION['msg'] = "";
                   echo"<meta HTTP-EQUIV='REFRESH' content='0; url=index.php#toregister'>";
                      //http_redirect("index.php#toregister");

  } 
    
else{
  session_unset(); 
$sql = "INSERT INTO registrations VALUES 
(

 '$_POST[usernamereg]',
 '$_POST[emailreg]',
 md5($_POST[passwordreg])

 
)";

if ($conn->query($sql) === TRUE) {

      echo"<meta HTTP-EQUIV='REFRESH' content='0; url=index.php'>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}


        } 
    }
    
 
}
$conn->close();
?>